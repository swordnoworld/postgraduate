// ruanzhu.h : main header file for the RUANZHU application
//

#if !defined(AFX_RUANZHU_H__17B96F18_9D20_4FFE_9DA7_F09001DBD902__INCLUDED_)
#define AFX_RUANZHU_H__17B96F18_9D20_4FFE_9DA7_F09001DBD902__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CRuanzhuApp:
// See ruanzhu.cpp for the implementation of this class
//

class CRuanzhuApp : public CWinApp
{
public:
	CRuanzhuApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRuanzhuApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CRuanzhuApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RUANZHU_H__17B96F18_9D20_4FFE_9DA7_F09001DBD902__INCLUDED_)
