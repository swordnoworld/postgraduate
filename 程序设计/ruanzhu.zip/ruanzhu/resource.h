//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ruanzhu.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RUANZHU_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_FP1                         1000
#define IDC_FN2                         1001
#define IDC_IDSW                        1002
#define IDC_MOTA                        1003
#define IDC_MOTASUAN                    1004
#define IDC_MOTACUN                     1005
#define IDC_DANSUAN                     1006
#define IDC_P                           1007
#define IDC_R                           1008
#define IDC_TP1                         1010
#define IDC_MAP                         1011
#define IDC_DANCUN                      1012
#define IDC_GT                          1013
#define IDC_IDTP                        1014
#define IDC_IDF1SUAN                    1015
#define IDC_IDFP                        1016
#define IDC_IDFN                        1017
#define IDC_IDF1CUN                     1018
#define IDC_IDF1                        1019
#define IDC_FN1                         1020
#define IDC_TP2                         1021
#define IDC_FP2                         1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
