; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CRuanzhuDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ruanzhu.h"

ClassCount=3
Class1=CRuanzhuApp
Class2=CRuanzhuDlg
Class3=CAboutDlg

ResourceCount=3
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_RUANZHU_DIALOG

[CLS:CRuanzhuApp]
Type=0
HeaderFile=ruanzhu.h
ImplementationFile=ruanzhu.cpp
Filter=N

[CLS:CRuanzhuDlg]
Type=0
HeaderFile=ruanzhuDlg.h
ImplementationFile=ruanzhuDlg.cpp
Filter=D
LastObject=CRuanzhuDlg
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=ruanzhuDlg.h
ImplementationFile=ruanzhuDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_RUANZHU_DIALOG]
Type=1
Class=CRuanzhuDlg
ControlCount=40
Control1=IDC_STATIC,button,1342177287
Control2=IDC_STATIC,button,1342177287
Control3=IDC_STATIC,button,1342177287
Control4=IDC_STATIC,static,1342308864
Control5=IDC_FP1,edit,1350639744
Control6=IDC_STATIC,static,1342308864
Control7=IDC_FN2,edit,1350631552
Control8=IDC_STATIC,static,1342308864
Control9=IDC_IDSW,edit,1350631552
Control10=IDC_STATIC,static,1342308864
Control11=IDC_MOTA,edit,1350641792
Control12=IDC_MOTASUAN,button,1342242816
Control13=IDC_MOTACUN,button,1342242816
Control14=IDC_STATIC,static,1342308864
Control15=IDC_STATIC,static,1342308864
Control16=IDC_DANSUAN,button,1342242816
Control17=IDC_P,edit,1350641792
Control18=IDC_STATIC,static,1342308864
Control19=IDC_R,edit,1350641792
Control20=IDC_TP1,edit,1350639744
Control21=IDC_DANCUN,button,1342242816
Control22=IDC_STATIC,static,1342308864
Control23=IDC_GT,edit,1350631552
Control24=IDC_STATIC,button,1342177287
Control25=IDC_STATIC,static,1342308864
Control26=IDC_IDTP,edit,1350631552
Control27=IDC_STATIC,static,1342308864
Control28=IDC_IDF1SUAN,button,1342242816
Control29=IDC_IDFP,edit,1350631552
Control30=IDC_STATIC,static,1342308864
Control31=IDC_IDFN,edit,1350631552
Control32=IDC_IDF1CUN,button,1342242816
Control33=IDC_STATIC,static,1342308864
Control34=IDC_IDF1,edit,1350641792
Control35=IDC_STATIC,static,1342308864
Control36=IDC_FN1,edit,1350639744
Control37=IDC_STATIC,static,1342308864
Control38=IDC_TP2,edit,1350631552
Control39=IDC_STATIC,static,1342308864
Control40=IDC_FP2,edit,1350631552

