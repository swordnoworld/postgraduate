// ruanzhuDlg.h : header file
//

#if !defined(AFX_RUANZHUDLG_H__C496B14A_0341_4331_8953_801F2AED0122__INCLUDED_)
#define AFX_RUANZHUDLG_H__C496B14A_0341_4331_8953_801F2AED0122__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CRuanzhuDlg dialog

class CRuanzhuDlg : public CDialog
{
// Construction
public:
	CRuanzhuDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CRuanzhuDlg)
	enum { IDD = IDD_RUANZHU_DIALOG };
	double	m_idf1;
	double	m_mota;
	double	m_p;
	double	m_r;
	double	m_fn1;   // �� double
	double	m_fn2;
	double	m_fp1;   // �� double
	double	m_fp2;
	double	m_gt;
	double	m_idfn;
	double	m_idfp;
	double	m_idsw;
	double	m_idtp;
	double	m_tp1;   // �� double
	double	m_tp2;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRuanzhuDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CRuanzhuDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDansuan();
	afx_msg void OnDancun();
	afx_msg void OnIdf1cun();
	afx_msg void OnIdf1suan();
	afx_msg void OnMotacun();
	afx_msg void OnMotasuan();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// ==================== �ļ����渨������ ====================
protected:
	void SaveToFile(LPCTSTR filename, const CString& content);
};

#endif // !defined(AFX_RUANZHUDLG_H__C496B14A_0341_4331_8953_801F2AED0122__INCLUDED_)